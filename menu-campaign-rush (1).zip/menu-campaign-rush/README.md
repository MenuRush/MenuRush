# Menu Campaign Rush! 🍕🍔🥤🐄

A retro 2D side-scrolling game where you're a restaurant marketer fighting through price increases, COVID chaos, and beef stampedes to launch your new menu.

## Local Development

```bash
npm install
npm run dev
```

Opens at `http://localhost:5173`

## Build for Production

```bash
npm run build
```

Creates a `dist/` folder with production files.

---

## Deploy to GitHub Pages (Free Hosting)

### Step 1: Create a GitHub Repository

1. Go to [github.com](https://github.com) and sign in (or create an account)
2. Click the **+** icon in the top-right → **New repository**
3. Name it `menu-campaign-rush` (or whatever you like)
4. Leave it **Public**
5. Do NOT check "Add a README" (we already have one)
6. Click **Create repository**

### Step 2: Push Your Code

Open a terminal in this project folder and run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/menu-campaign-rush.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

### Step 3: Deploy with Vercel (Easiest - Recommended)

1. Go to [vercel.com](https://vercel.com) and sign in with GitHub
2. Click **"Add New..."** → **Project**
3. Find and import your `menu-campaign-rush` repo
4. Vercel auto-detects Vite — just click **Deploy**
5. In ~60 seconds your game is live at `https://menu-campaign-rush.vercel.app`

**To connect your custom domain (GoDaddy, etc):**
- In Vercel: Project Settings → Domains → Add your domain
- In your domain registrar: Add these DNS records:
  - A record: `@` → `76.76.21.21`
  - CNAME record: `www` → `cname.vercel-dns.com`

### Alternative: Deploy with Netlify

1. Run `npm run build` locally
2. Go to [netlify.com](https://netlify.com) → sign up
3. Drag and drop your `dist/` folder onto the Netlify dashboard
4. Instant live URL!

### Alternative: GitHub Pages (Free, built-in)

1. Install the deploy plugin:
   ```bash
   npm install --save-dev gh-pages
   ```

2. Add to `package.json` scripts:
   ```json
   "deploy": "npm run build && gh-pages -d dist"
   ```

3. Add `base` to `vite.config.js`:
   ```js
   export default defineConfig({
     base: '/menu-campaign-rush/',
     plugins: [react()],
   })
   ```

4. Run:
   ```bash
   npm run deploy
   ```

5. Go to your repo on GitHub → Settings → Pages
   - Source: **Deploy from a branch**
   - Branch: **gh-pages** / **root**
   - Click Save

6. Your game will be live at:
   `https://YOUR_USERNAME.github.io/menu-campaign-rush/`

---

## Updating the Game

- **Vercel/Netlify + GitHub:** Just push changes — it auto-deploys
- **GitHub Pages:** Run `npm run deploy` again
- **Manual hosting:** Run `npm run build` and re-upload `dist/`

---

## Game Controls

| Key       | Action                  | Points |
|-----------|-------------------------|--------|
| ↑ Arrow   | Jump                    | +2     |
| Spacebar  | Swing sword             | +5     |
| Land on top | Stomp obstacle        | +2     |
| P         | Pause / Resume          | —      |

### Special Levels
- **Level 2 (COVID):** Masks & distancing signs + halfway takeout car mini-game (Spacebar throws orders → +1 each)
- **Level 3 (Menu Empire):** Halfway beef stampede — throw burgers at cows! (Spacebar → +1 each)

## Project Structure

```
menu-campaign-rush/
├── index.html              ← HTML entry point
├── package.json            ← Dependencies and scripts
├── vite.config.js          ← Vite build config
├── .gitignore              ← Git ignore rules
├── README.md               ← You are here
└── src/
    ├── main.jsx            ← React bootstrap
    └── MenuCampaignRush.jsx ← The entire game
```
