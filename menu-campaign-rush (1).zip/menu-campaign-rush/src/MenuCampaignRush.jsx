import { useState, useEffect, useRef, useCallback } from "react";

const GAME_WIDTH = 800;
const GAME_HEIGHT = 500;
const GROUND_Y = 400;
const PLAYER_WIDTH = 40;
const PLAYER_HEIGHT = 56;
const GRAVITY = 0.7;
const JUMP_FORCE = -14;
const LEVEL_DURATION = 35;
const TOTAL_LEVELS = 3;
const MAX_LIVES = 5;
const STOMP_POINTS = 2;
const SMASH_POINTS = 5;
const JUMP_POINTS = 2;
const TAKEOUT_POINTS = 1;
const TAKEOUT_START = 17; // seconds remaining when car arrives (halfway)
const TAKEOUT_DURATION = 10;
const BEEF_HIKE_START = 17; // seconds remaining when beef event starts (halfway)
const BEEF_HIKE_DURATION = 15;

const LEVEL_DATA = [
  { year: 2021, locations: 1, name: "The First Location", speed: 3, spawnMin: 2200, spawnMax: 3000, bg: "#1a1a2e", covid: false },
  { year: 2023, locations: 250, name: "COVID HITS", speed: 5.5, spawnMin: 1100, spawnMax: 1800, bg: "#1a0a0a", covid: true },
  { year: 2025, locations: 2500, name: "Menu Empire", speed: 8.5, spawnMin: 500, spawnMax: 900, bg: "#0a0a23", covid: false },
];

const FOOD_TYPES = ["pizza", "burger", "soda", "egg"];
const COVID_TYPES = ["mask", "distancing"];
const PIXEL_FONT = `"Press Start 2P", monospace`;

// ====== DRAW FOOD ======

function drawPizzaSlice(ctx, x, y, w, h) {
  ctx.fillStyle = "#f0c040";
  ctx.beginPath();
  ctx.moveTo(x + w / 2, y + 4);
  ctx.lineTo(x + 4, y + h - 2);
  ctx.lineTo(x + w - 4, y + h - 2);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#c8900a";
  ctx.beginPath();
  ctx.moveTo(x + 4, y + h - 2);
  ctx.lineTo(x + w - 4, y + h - 2);
  ctx.lineTo(x + w - 2, y + h + 2);
  ctx.lineTo(x + 2, y + h + 2);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#cc3333";
  ctx.fillRect(x + w / 2 - 3, y + h / 2, 6, 5);
  ctx.fillRect(x + w / 2 - 7, y + h - 10, 5, 4);
  ctx.fillRect(x + w / 2 + 3, y + h - 12, 5, 4);
  ctx.strokeStyle = "#8B6914";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x + w / 2, y + 4);
  ctx.lineTo(x + 4, y + h - 2);
  ctx.lineTo(x + w - 4, y + h - 2);
  ctx.closePath();
  ctx.stroke();
}

function drawBurger(ctx, x, y, w, h) {
  ctx.fillStyle = "#d4881c";
  ctx.fillRect(x + 2, y + 2, w - 4, h / 3);
  ctx.fillRect(x + 4, y, w - 8, 4);
  ctx.fillStyle = "#f5e6c8";
  ctx.fillRect(x + 8, y + 3, 3, 2);
  ctx.fillRect(x + 16, y + 4, 3, 2);
  ctx.fillRect(x + 24, y + 3, 3, 2);
  ctx.fillStyle = "#5cb85c";
  ctx.fillRect(x, y + h / 3 + 2, w, 4);
  ctx.fillStyle = "#6b3a1f";
  ctx.fillRect(x + 2, y + h / 3 + 6, w - 4, h / 3 - 2);
  ctx.fillStyle = "#ffcc00";
  ctx.fillRect(x, y + h / 3 + 6, w, 3);
  ctx.fillStyle = "#d4881c";
  ctx.fillRect(x + 2, y + h * 2 / 3 + 4, w - 4, h / 3 - 4);
  ctx.strokeStyle = "#8B5E14";
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 1, y + 1, w - 2, h - 2);
}

function drawSoda(ctx, x, y, w, h) {
  ctx.fillStyle = "#e74c3c";
  ctx.fillRect(x + 4, y + 8, w - 8, h - 10);
  ctx.fillRect(x + 6, y + h - 6, w - 12, 6);
  ctx.fillStyle = "#fff";
  ctx.fillRect(x + 2, y + 6, w - 4, 4);
  ctx.fillStyle = "#c0392b";
  ctx.fillRect(x + 3, y + 2, w - 6, 6);
  ctx.fillStyle = "#f5f5f5";
  ctx.fillRect(x + w / 2 + 2, y - 6, 3, 14);
  ctx.fillRect(x + w / 2 + 2, y - 6, 8, 3);
  ctx.fillStyle = "#fff";
  ctx.fillRect(x + 6, y + 18, w - 12, 3);
  ctx.fillRect(x + 6, y + 24, w - 12, 3);
  ctx.strokeStyle = "#8B2020";
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 3, y + 2, w - 6, h - 2);
}

function drawEgg(ctx, x, y, w, h) {
  ctx.fillStyle = "#fef9e7";
  ctx.beginPath();
  ctx.ellipse(x + w / 2, y + h / 2 + 2, w / 2 - 2, h / 2 - 1, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#d4c5a0";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.ellipse(x + w / 2, y + h / 2 + 2, w / 2 - 2, h / 2 - 1, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = "rgba(255,255,255,0.5)";
  ctx.beginPath();
  ctx.ellipse(x + w / 2 - 2, y + h / 3, w / 4, h / 6, -0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#c4a96a";
  ctx.fillRect(x + w / 2 - 5, y + h / 2 - 2, 2, 2);
  ctx.fillRect(x + w / 2 + 3, y + h / 2 + 4, 2, 2);
  ctx.fillRect(x + w / 2 - 1, y + h / 2 + 6, 2, 2);
  ctx.strokeStyle = "#b8a070";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x + w / 2 + 2, y + h / 2 - 2);
  ctx.lineTo(x + w / 2 + 5, y + h / 2 + 2);
  ctx.lineTo(x + w / 2 + 3, y + h / 2 + 5);
  ctx.stroke();
}

// ====== DRAW COVID OBSTACLES ======

function drawMask(ctx, x, y, w, h) {
  // Mask body - light blue surgical mask
  ctx.fillStyle = "#7ec8e3";
  ctx.fillRect(x + 2, y + 4, w - 4, h - 8);
  // Pleats
  ctx.strokeStyle = "#5ba3c9";
  ctx.lineWidth = 1;
  for (let py = y + 8; py < y + h - 6; py += 5) {
    ctx.beginPath();
    ctx.moveTo(x + 4, py);
    ctx.lineTo(x + w - 4, py);
    ctx.stroke();
  }
  // Ear loops
  ctx.strokeStyle = "#fff";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(x + 1, y + h / 2, 6, -Math.PI * 0.4, Math.PI * 0.4);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(x + w - 1, y + h / 2, 6, Math.PI * 0.6, Math.PI * 1.4);
  ctx.stroke();
  // Metal nose strip
  ctx.fillStyle = "#ccc";
  ctx.fillRect(x + 6, y + 4, w - 12, 3);
  // Border
  ctx.strokeStyle = "#4a90b0";
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 2, y + 4, w - 4, h - 8);
}

function drawDistancingSign(ctx, x, y, w, h) {
  // Red circle sign
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(x + w / 2, y + h / 2, w / 2 - 2, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#cc0000";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(x + w / 2, y + h / 2, w / 2 - 2, 0, Math.PI * 2);
  ctx.stroke();
  // Two stick figures
  ctx.fillStyle = "#333";
  // Left figure
  ctx.fillRect(x + 8, y + h / 2 - 6, 4, 10);
  ctx.fillRect(x + 9, y + h / 2 - 10, 3, 3);
  ctx.fillRect(x + 6, y + h / 2 - 2, 2, 6);
  ctx.fillRect(x + 13, y + h / 2 - 2, 2, 6);
  // Right figure
  ctx.fillRect(x + w - 12, y + h / 2 - 6, 4, 10);
  ctx.fillRect(x + w - 12, y + h / 2 - 10, 3, 3);
  ctx.fillRect(x + w - 14, y + h / 2 - 2, 2, 6);
  ctx.fillRect(x + w - 9, y + h / 2 - 2, 2, 6);
  // Arrow between them (6ft)
  ctx.fillStyle = "#cc0000";
  ctx.fillRect(x + 15, y + h / 2, w - 30, 2);
  ctx.font = `bold 5px ${PIXEL_FONT}`;
  ctx.fillStyle = "#cc0000";
  ctx.textAlign = "center";
  ctx.fillText("6FT", x + w / 2, y + h / 2 + 10);
}

function drawCow(ctx, x, y, w, h) {
  // Body - black angus (dark) with lighter highlights for visibility
  ctx.fillStyle = "#222";
  ctx.fillRect(x + 8, y + 6, w - 14, h - 14);
  // Belly lighter
  ctx.fillStyle = "#3a3a3a";
  ctx.fillRect(x + 12, y + h - 16, w - 22, 6);
  // Head - facing LEFT toward player
  ctx.fillStyle = "#222";
  ctx.fillRect(x - 2, y + 0, 16, 16);
  // Snout - on left side
  ctx.fillStyle = "#5a4a3a";
  ctx.fillRect(x - 6, y + 8, 8, 8);
  // Nostrils
  ctx.fillStyle = "#3a2a1a";
  ctx.fillRect(x - 4, y + 10, 2, 2);
  ctx.fillRect(x - 4, y + 13, 2, 2);
  // Eyes - facing left, white with pupil for visibility
  ctx.fillStyle = "#fff";
  ctx.fillRect(x + 2, y + 4, 4, 4);
  ctx.fillStyle = "#ff2222";
  ctx.fillRect(x + 3, y + 5, 2, 2);
  // Horns - on top of head
  ctx.fillStyle = "#ddc090";
  ctx.fillRect(x + 0, y - 4, 3, 6);
  ctx.fillRect(x + 10, y - 4, 3, 6);
  // Horn tips
  ctx.fillStyle = "#f0dab0";
  ctx.fillRect(x - 1, y - 5, 3, 3);
  ctx.fillRect(x + 11, y - 5, 3, 3);
  // Ears
  ctx.fillStyle = "#2a2a2a";
  ctx.fillRect(x - 2, y + 0, 3, 5);
  ctx.fillRect(x + 12, y + 0, 3, 5);
  // Tail - on right side, curving up
  ctx.fillStyle = "#222";
  ctx.fillRect(x + w - 8, y + 6, 8, 3);
  ctx.fillRect(x + w - 2, y + 2, 4, 6);
  // Tail tuft
  ctx.fillStyle = "#3a3a3a";
  ctx.fillRect(x + w, y + 0, 4, 6);
  // Legs
  ctx.fillStyle = "#1a1a1a";
  ctx.fillRect(x + 8, y + h - 12, 5, 12);
  ctx.fillRect(x + 16, y + h - 12, 5, 12);
  ctx.fillRect(x + w - 18, y + h - 12, 5, 12);
  ctx.fillRect(x + w - 10, y + h - 12, 5, 12);
  // Hooves
  ctx.fillStyle = "#555";
  ctx.fillRect(x + 7, y + h - 2, 7, 2);
  ctx.fillRect(x + 15, y + h - 2, 7, 2);
  ctx.fillRect(x + w - 19, y + h - 2, 7, 2);
  ctx.fillRect(x + w - 11, y + h - 2, 7, 2);
  // Body outline for visibility against dark background
  ctx.strokeStyle = "#555";
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 7, y + 5, w - 12, h - 13);
}

function drawBeefBanner(ctx, scroll, alpha) {
  if (alpha <= 0) return;
  ctx.globalAlpha = alpha;
  ctx.fillStyle = "#4a1a00";
  ctx.fillRect(0, 60, GAME_WIDTH, 50);
  ctx.strokeStyle = "#ff6b35";
  ctx.lineWidth = 2;
  ctx.strokeRect(0, 60, GAME_WIDTH, 50);
  // Flame-colored stripes
  ctx.fillStyle = "#ff4500";
  for (let i = -2; i < GAME_WIDTH / 30 + 2; i++) {
    const sx = i * 30 - (scroll * 0.5) % 30;
    ctx.fillRect(sx, 60, 15, 4);
    ctx.fillRect(sx, 106, 15, 4);
  }
  ctx.font = `18px ${PIXEL_FONT}`;
  ctx.fillStyle = "#ffcc00";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("BEEF PRICE HIKE!", GAME_WIDTH / 2, 85);
  ctx.globalAlpha = 1;
}

function drawFoodObstacle(ctx, obs) {
  ctx.font = `bold 9px ${PIXEL_FONT}`;
  ctx.textAlign = "center";
  ctx.textBaseline = "bottom";

  if (obs.food === "cow") {
    ctx.fillStyle = "#ff6b35";
    ctx.fillText("BEEF", obs.x + obs.w / 2, obs.y - 16);
    ctx.fillText("PRICE!", obs.x + obs.w / 2, obs.y - 4);
    drawCow(ctx, obs.x, obs.y, obs.w, obs.h);
  } else if (obs.food === "egg") {
    ctx.fillStyle = "#ffa502";
    ctx.fillText("EGG", obs.x + obs.w / 2, obs.y - 16);
    ctx.fillText("SHORTAGE!", obs.x + obs.w / 2, obs.y - 4);
    drawEgg(ctx, obs.x, obs.y, obs.w, obs.h);
  } else if (obs.food === "mask") {
    ctx.fillStyle = "#7ec8e3";
    ctx.fillText("MASK", obs.x + obs.w / 2, obs.y - 16);
    ctx.fillText("UP!", obs.x + obs.w / 2, obs.y - 4);
    drawMask(ctx, obs.x, obs.y, obs.w, obs.h);
  } else if (obs.food === "distancing") {
    ctx.fillStyle = "#cc0000";
    ctx.fillText("STAY", obs.x + obs.w / 2, obs.y - 16);
    ctx.fillText("BACK!", obs.x + obs.w / 2, obs.y - 4);
    drawDistancingSign(ctx, obs.x, obs.y, obs.w, obs.h);
  } else {
    ctx.fillStyle = "#ff4757";
    ctx.fillText("PRICE", obs.x + obs.w / 2, obs.y - 16);
    ctx.fillText("INCREASE", obs.x + obs.w / 2, obs.y - 4);
    if (obs.food === "pizza") drawPizzaSlice(ctx, obs.x, obs.y, obs.w, obs.h);
    else if (obs.food === "burger") drawBurger(ctx, obs.x, obs.y, obs.w, obs.h);
    else drawSoda(ctx, obs.x, obs.y, obs.w, obs.h);
  }

  if (obs.food !== "cow") {
    ctx.strokeStyle = "rgba(255,255,100,0.5)";
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.strokeRect(obs.x - 2, obs.y - 2, obs.w + 4, obs.h + 4);
    ctx.setLineDash([]);
  }
}

// ====== DRAW TAKEOUT CAR ======

function drawCar(ctx, carX, trunkOpen) {
  const cy = GROUND_Y - 52;
  // Car body
  ctx.fillStyle = "#3a3a5c";
  ctx.fillRect(carX, cy + 10, 100, 30);
  // Roof
  ctx.fillStyle = "#2e2e4a";
  ctx.fillRect(carX + 15, cy, 50, 16);
  ctx.fillRect(carX + 10, cy + 10, 60, 6);
  // Windows
  ctx.fillStyle = "#5588aa";
  ctx.fillRect(carX + 20, cy + 2, 18, 10);
  ctx.fillRect(carX + 42, cy + 2, 18, 10);
  // Wheels
  ctx.fillStyle = "#111";
  ctx.beginPath();
  ctx.arc(carX + 22, cy + 42, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(carX + 78, cy + 42, 8, 0, Math.PI * 2);
  ctx.fill();
  // Hubcaps
  ctx.fillStyle = "#888";
  ctx.beginPath();
  ctx.arc(carX + 22, cy + 42, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(carX + 78, cy + 42, 3, 0, Math.PI * 2);
  ctx.fill();
  // Taillights (facing left since car backs up from right)
  ctx.fillStyle = "#ff3333";
  ctx.fillRect(carX, cy + 14, 4, 6);
  ctx.fillRect(carX, cy + 28, 4, 6);
  // Trunk (open, on the left/front of car as it backs in)
  if (trunkOpen) {
    ctx.fillStyle = "#2a2a44";
    ctx.fillRect(carX - 4, cy + 6, 8, 28);
    // Trunk lid open upward
    ctx.fillStyle = "#3a3a5c";
    ctx.fillRect(carX - 8, cy - 2, 12, 10);
    // Trunk interior glow
    ctx.fillStyle = "rgba(255,200,50,0.2)";
    ctx.fillRect(carX - 2, cy + 8, 6, 24);
  }
  // Bumper
  ctx.fillStyle = "#888";
  ctx.fillRect(carX - 2, cy + 36, 6, 4);
  ctx.fillRect(carX + 96, cy + 36, 6, 4);
}

function drawTakeoutBag(ctx, bag) {
  // Brown paper bag
  ctx.fillStyle = "#c49a6c";
  ctx.fillRect(bag.x, bag.y, 12, 14);
  ctx.fillStyle = "#a0784c";
  ctx.fillRect(bag.x + 2, bag.y, 8, 3);
  // Handle
  ctx.strokeStyle = "#8B6540";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(bag.x + 6, bag.y - 1, 3, Math.PI, 0);
  ctx.stroke();
  // Logo dot
  ctx.fillStyle = "#e74c3c";
  ctx.fillRect(bag.x + 4, bag.y + 6, 4, 3);
}

// ====== COVID HITS BANNER ======

function drawCovidBanner(ctx, scroll, alpha) {
  if (alpha <= 0) return;
  ctx.globalAlpha = alpha;
  // Dark red banner across top area
  ctx.fillStyle = "#8b0000";
  ctx.fillRect(0, 60, GAME_WIDTH, 50);
  ctx.strokeStyle = "#ff0000";
  ctx.lineWidth = 2;
  ctx.strokeRect(0, 60, GAME_WIDTH, 50);
  // Hazard stripes
  ctx.fillStyle = "#ff4444";
  for (let i = -2; i < GAME_WIDTH / 30 + 2; i++) {
    const sx = i * 30 - (scroll * 0.5) % 30;
    ctx.fillRect(sx, 60, 15, 4);
    ctx.fillRect(sx, 106, 15, 4);
  }
  ctx.font = `18px ${PIXEL_FONT}`;
  ctx.fillStyle = "#fff";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("COVID HITS", GAME_WIDTH / 2, 85);
  ctx.globalAlpha = 1;
}

// ====== DRAW CHARACTERS ======

function drawMaleChar(ctx, x, y, frame, isJumping, isSword) {
  const legFrame = frame % 4;
  ctx.fillStyle = "#4a69bd";
  ctx.fillRect(x + 12, y + 16, 16, 20);
  ctx.fillStyle = "#fad390";
  ctx.fillRect(x + 12, y + 4, 16, 14);
  ctx.fillStyle = "#2c2c54";
  ctx.fillRect(x + 10, y + 2, 20, 6);
  ctx.fillStyle = "#2c2c54";
  ctx.fillRect(x + 16, y + 10, 3, 3);
  ctx.fillRect(x + 22, y + 10, 3, 3);
  ctx.fillStyle = "#e74c3c";
  ctx.fillRect(x + 18, y + 18, 4, 10);
  ctx.fillStyle = "#fad390";
  ctx.fillRect(x + 6, y + 20, 6, 4);
  ctx.fillStyle = "#8B4513";
  ctx.fillRect(x + 0, y + 24, 12, 10);
  ctx.fillStyle = "#DAA520";
  ctx.fillRect(x + 4, y + 23, 4, 2);
  if (isSword) {
    ctx.fillStyle = "#fad390";
    ctx.fillRect(x + 28, y + 18, 8, 4);
    ctx.fillStyle = "#c0c0c0";
    ctx.fillRect(x + 36, y + 14, 4, 16);
    ctx.fillRect(x + 34, y + 10, 8, 4);
    ctx.fillStyle = "#DAA520";
    ctx.fillRect(x + 32, y + 18, 12, 4);
    ctx.fillStyle = "rgba(255,255,200,0.3)";
    ctx.fillRect(x + 34, y + 8, 8, 24);
  } else {
    ctx.fillStyle = "#fad390";
    ctx.fillRect(x + 28, y + 20, 6, 4);
  }
  ctx.fillStyle = "#2c3e50";
  if (isJumping) {
    ctx.fillRect(x + 12, y + 36, 6, 12);
    ctx.fillRect(x + 22, y + 36, 6, 12);
  } else {
    const offsets = [[0, 6], [3, 3], [6, 0], [3, 3]];
    ctx.fillRect(x + 12, y + 36 + offsets[legFrame][0], 6, 16 - offsets[legFrame][0]);
    ctx.fillRect(x + 22, y + 36 + offsets[legFrame][1], 6, 16 - offsets[legFrame][1]);
  }
  ctx.fillStyle = "#2c2c54";
  if (!isJumping) {
    const offsets = [[0, 6], [3, 3], [6, 0], [3, 3]];
    ctx.fillRect(x + 10, y + 48 + Math.max(0, 2 - offsets[legFrame][0]), 10, 4);
    ctx.fillRect(x + 20, y + 48 + Math.max(0, 2 - offsets[legFrame][1]), 10, 4);
  } else {
    ctx.fillRect(x + 10, y + 46, 10, 4);
    ctx.fillRect(x + 20, y + 46, 10, 4);
  }
}

function drawFemaleChar(ctx, x, y, frame, isJumping, isSword) {
  const legFrame = frame % 4;
  ctx.fillStyle = "#8e3a59";
  ctx.fillRect(x + 12, y + 16, 16, 18);
  ctx.fillStyle = "#a04468";
  ctx.fillRect(x + 12, y + 16, 4, 10);
  ctx.fillRect(x + 24, y + 16, 4, 10);
  ctx.fillStyle = "#f0e6d3";
  ctx.fillRect(x + 16, y + 17, 8, 8);
  ctx.fillStyle = "#2c3e50";
  ctx.fillRect(x + 10, y + 34, 20, 8);
  ctx.fillStyle = "#fad390";
  ctx.fillRect(x + 12, y + 4, 16, 14);
  ctx.fillStyle = "#7B3F00";
  ctx.fillRect(x + 10, y + 1, 20, 7);
  ctx.fillRect(x + 10, y + 4, 4, 10);
  ctx.fillRect(x + 4, y + 4, 8, 4);
  ctx.fillRect(x + 0, y + 6, 6, 4);
  ctx.fillRect(x - 2, y + 8, 5, 6);
  ctx.fillRect(x - 4, y + 12, 5, 6);
  ctx.fillRect(x - 3, y + 16, 4, 5);
  ctx.fillStyle = "#e74c3c";
  ctx.fillRect(x + 5, y + 6, 3, 3);
  ctx.fillStyle = "#2c2c54";
  ctx.fillRect(x + 16, y + 10, 3, 3);
  ctx.fillRect(x + 22, y + 10, 3, 3);
  ctx.fillRect(x + 15, y + 9, 1, 1);
  ctx.fillRect(x + 25, y + 9, 1, 1);
  ctx.fillStyle = "#c0392b";
  ctx.fillRect(x + 18, y + 14, 5, 2);
  ctx.fillStyle = "#DAA520";
  ctx.fillRect(x + 16, y + 17, 8, 1);
  ctx.fillRect(x + 19, y + 18, 2, 2);
  ctx.fillStyle = "#fad390";
  ctx.fillRect(x + 6, y + 20, 6, 4);
  ctx.fillStyle = "#c0392b";
  ctx.fillRect(x + 0, y + 24, 12, 8);
  ctx.fillStyle = "#DAA520";
  ctx.fillRect(x + 2, y + 23, 8, 2);
  ctx.fillRect(x + 5, y + 21, 2, 3);
  if (isSword) {
    ctx.fillStyle = "#fad390";
    ctx.fillRect(x + 28, y + 18, 8, 4);
    ctx.fillStyle = "#c0c0c0";
    ctx.fillRect(x + 36, y + 14, 4, 16);
    ctx.fillRect(x + 34, y + 10, 8, 4);
    ctx.fillStyle = "#DAA520";
    ctx.fillRect(x + 32, y + 18, 12, 4);
    ctx.fillStyle = "rgba(255,255,200,0.3)";
    ctx.fillRect(x + 34, y + 8, 8, 24);
  } else {
    ctx.fillStyle = "#fad390";
    ctx.fillRect(x + 28, y + 20, 6, 4);
  }
  ctx.fillStyle = "#d4a574";
  if (isJumping) {
    ctx.fillRect(x + 14, y + 42, 5, 8);
    ctx.fillRect(x + 22, y + 42, 5, 8);
  } else {
    const offsets = [[0, 6], [3, 3], [6, 0], [3, 3]];
    ctx.fillRect(x + 14, y + 42 + offsets[legFrame][0], 5, 10 - offsets[legFrame][0]);
    ctx.fillRect(x + 22, y + 42 + offsets[legFrame][1], 5, 10 - offsets[legFrame][1]);
  }
  ctx.fillStyle = "#c0392b";
  if (!isJumping) {
    const offsets = [[0, 6], [3, 3], [6, 0], [3, 3]];
    ctx.fillRect(x + 12, y + 48 + Math.max(0, 2 - offsets[legFrame][0]), 9, 4);
    ctx.fillRect(x + 20, y + 48 + Math.max(0, 2 - offsets[legFrame][1]), 9, 4);
  } else {
    ctx.fillRect(x + 12, y + 48, 9, 4);
    ctx.fillRect(x + 20, y + 48, 9, 4);
  }
}

function drawPixelChar(ctx, x, y, frame, isJumping, isSword, gender) {
  if (gender === "female") drawFemaleChar(ctx, x, y, frame, isJumping, isSword);
  else drawMaleChar(ctx, x, y, frame, isJumping, isSword);
}

// ====== ENVIRONMENT ======

function drawGround(ctx, scroll, isCovid) {
  ctx.fillStyle = isCovid ? "#2a2020" : "#3d5c3a";
  ctx.fillRect(0, GROUND_Y, GAME_WIDTH, GAME_HEIGHT - GROUND_Y);
  ctx.fillStyle = isCovid ? "#3a2a2a" : "#4a6e46";
  for (let i = -1; i < GAME_WIDTH / 32 + 1; i++) {
    const tx = (i * 32 - (scroll % 32));
    ctx.fillRect(tx, GROUND_Y, 30, 2);
    if (i % 2 === 0) ctx.fillRect(tx + 8, GROUND_Y + 8, 16, 2);
  }
  ctx.fillStyle = isCovid ? "#1a1010" : "#2d4a2a";
  ctx.fillRect(0, GROUND_Y, GAME_WIDTH, 3);
}

function drawClouds(ctx, scroll) {
  ctx.fillStyle = "rgba(255,255,255,0.08)";
  for (let i = 0; i < 5; i++) {
    const cx = ((i * 200 + 50) - (scroll * 0.2) % 1000 + 1000) % 1000;
    ctx.fillRect(cx, 40 + i * 30, 60, 16);
    ctx.fillRect(cx + 10, 32 + i * 30, 40, 24);
  }
}

function drawBuildings(ctx, scroll, locations) {
  const buildingCount = Math.min(locations, 8);
  for (let i = 0; i < buildingCount; i++) {
    const bx = ((i * 120 + 30) - (scroll * 0.3) % 960 + 960) % 960;
    const bh = 60 + (i * 37) % 80;
    ctx.fillStyle = "rgba(255,255,255,0.04)";
    ctx.fillRect(bx, GROUND_Y - bh, 50, bh);
    ctx.fillStyle = "rgba(255,200,50,0.1)";
    for (let wy = 0; wy < bh - 10; wy += 16) {
      for (let wx = 8; wx < 42; wx += 14) {
        ctx.fillRect(bx + wx, GROUND_Y - bh + 8 + wy, 6, 8);
      }
    }
  }
}

function drawParticle(ctx, p) {
  ctx.fillStyle = p.color;
  ctx.globalAlpha = p.life;
  ctx.fillRect(p.x, p.y, p.size, p.size);
  ctx.globalAlpha = 1;
}

function drawSwordSlash(ctx, x, y, frame) {
  const alpha = Math.max(0, 1 - frame / 8);
  ctx.strokeStyle = `rgba(255, 255, 200, ${alpha})`;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(x + 36, y + 20, 20 + frame * 3, -Math.PI * 0.4, Math.PI * 0.4);
  ctx.stroke();
}

function drawScorePopup(ctx, popup) {
  ctx.globalAlpha = Math.max(0, popup.life);
  ctx.font = `bold 10px ${PIXEL_FONT}`;
  ctx.fillStyle = popup.color;
  ctx.textAlign = "center";
  ctx.fillText(popup.text, popup.x, popup.y);
  ctx.globalAlpha = 1;
}

function drawHealthBar(ctx, lives, maxLives) {
  const barX = GAME_WIDTH - 170;
  const barY = 10;
  const barW = 156;
  const barH = 16;
  ctx.fillStyle = "rgba(0,0,0,0.5)";
  ctx.fillRect(barX - 1, barY - 1, barW + 2, barH + 2);
  for (let i = 0; i < maxLives; i++) {
    const segX = barX + i * (barW / maxLives) + 1;
    const segW = (barW / maxLives) - 2;
    if (i < lives) {
      if (lives <= 1) ctx.fillStyle = "#ff2222";
      else if (lives <= 2) ctx.fillStyle = "#ff6b35";
      else if (lives <= 3) ctx.fillStyle = "#ffcc00";
      else ctx.fillStyle = "#44cc44";
      ctx.fillRect(segX, barY, segW, barH);
      ctx.fillStyle = "rgba(255,255,255,0.25)";
      ctx.fillRect(segX, barY, segW, barH / 3);
    } else {
      ctx.fillStyle = "rgba(80,0,0,0.5)";
      ctx.fillRect(segX, barY, segW, barH);
    }
  }
  ctx.strokeStyle = "#fff";
  ctx.lineWidth = 1;
  ctx.strokeRect(barX, barY, barW, barH);
  ctx.font = `7px ${PIXEL_FONT}`;
  ctx.fillStyle = "#fff";
  ctx.textAlign = "right";
  ctx.fillText("HP", barX - 4, barY + 12);
}

// ====== MAIN COMPONENT ======

export default function MenuCampaignRush() {
  const canvasRef = useRef(null);
  const gsRef = useRef(null);
  const keysRef = useRef({});
  const animRef = useRef(null);
  const lastTimeRef = useRef(0);
  const spawnAccumRef = useRef(0);
  const nextSpawnRef = useRef(2000);
  const isPausedRef = useRef(false);
  const genderRef = useRef("male");

  const [screen, setScreen] = useState("title");
  const [playerName, setPlayerName] = useState("");
  const [gender, setGender] = useState("male");
  const [currentLevel, setCurrentLevel] = useState(0);
  const [displayScore, setDisplayScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(LEVEL_DURATION);
  const [displayLives, setDisplayLives] = useState(MAX_LIVES);
  const [leaderboard, setLeaderboard] = useState([]);
  const [showLevelIntro, setShowLevelIntro] = useState(false);
  const [introData, setIntroData] = useState(null);
  const [gameOverScore, setGameOverScore] = useState(0);
  const [displayCombo, setDisplayCombo] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const screenRef = useRef(screen);
  const currentLevelRef = useRef(currentLevel);
  const playerNameRef = useRef(playerName);
  const leaderboardRef = useRef(leaderboard);
  screenRef.current = screen;
  currentLevelRef.current = currentLevel;
  playerNameRef.current = playerName;
  leaderboardRef.current = leaderboard;

  useEffect(() => { genderRef.current = gender; }, [gender]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem("mcr-leaderboard");
      if (stored) setLeaderboard(JSON.parse(stored));
    } catch (e) {
      console.log("No saved leaderboard found");
    }
  }, []);

  const saveLeaderboard = useCallback((newBoard) => {
    try {
      localStorage.setItem("mcr-leaderboard", JSON.stringify(newBoard));
    } catch (e) { console.error("Save failed", e); }
  }, []);

  const randomSpawnDelay = useCallback((level) => {
    const ld = LEVEL_DATA[level];
    return ld.spawnMin + Math.random() * (ld.spawnMax - ld.spawnMin);
  }, []);

  const initGameState = useCallback((level, carryScore, carryLives) => {
    gsRef.current = {
      player: { x: 160, y: GROUND_Y - PLAYER_HEIGHT, vy: 0, isJumping: false, frame: 0 },
      obstacles: [],
      particles: [],
      scorePopups: [],
      takeoutBags: [],
      scroll: 0,
      score: carryScore || 0,
      lives: carryLives || MAX_LIVES,
      timeLeft: LEVEL_DURATION,
      level: level,
      speed: LEVEL_DATA[level].speed,
      swordActive: false,
      swordTimer: 0,
      swordCooldown: 0,
      combo: 0,
      comboTimer: 0,
      hitFlash: 0,
      frameCount: 0,
      slashFrame: -1,
      invincible: 0,
      shakeX: 0,
      shakeY: 0,
      running: true,
      // COVID takeout car state
      covidBannerAlpha: LEVEL_DATA[level].covid ? 1.0 : 0,
      covidBannerTimer: LEVEL_DATA[level].covid ? 180 : 0, // frames to show banner
      takeoutActive: false,
      takeoutTimer: 0,
      takeoutCarX: GAME_WIDTH + 120, // starts off-screen right
      takeoutCarState: "hidden", // hidden, entering, parked, leaving
      takeoutCooldown: 0,
      takeoutTriggered: false,
      // Beef Price Hike state (level 5)
      beefHikeActive: false,
      beefHikeTriggered: false,
      beefBannerAlpha: 0,
      beefBannerTimer: 0,
      beefCooldown: 0,
      burgerProjectiles: [],
    };
    spawnAccumRef.current = 0;
    nextSpawnRef.current = randomSpawnDelay(level);
    lastTimeRef.current = 0;
  }, [randomSpawnDelay]);

  const endGame = useCallback((finalScore, reachedLevel) => {
    const board = leaderboardRef.current;
    const newBoard = [...board, { name: playerNameRef.current, score: finalScore, level: reachedLevel }]
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
    setLeaderboard(newBoard);
    saveLeaderboard(newBoard);
    setGameOverScore(finalScore);
  }, [saveLeaderboard]);

  const startGame = useCallback(() => {
    if (!playerName.trim()) return;
    initGameState(0, 0, MAX_LIVES);
    setCurrentLevel(0);
    setDisplayScore(0);
    setTimeLeft(LEVEL_DURATION);
    setDisplayLives(MAX_LIVES);
    setDisplayCombo(0);
    setIsPaused(false);
    isPausedRef.current = false;
    setShowLevelIntro(true);
    setIntroData(LEVEL_DATA[0]);
    setTimeout(() => {
      setShowLevelIntro(false);
      setScreen("playing");
    }, 3000);
  }, [playerName, initGameState]);

  const togglePause = useCallback(() => {
    setIsPaused(prev => {
      const next = !prev;
      isPausedRef.current = next;
      if (!next) lastTimeRef.current = 0;
      return next;
    });
  }, []);

  useEffect(() => {
    const handleDown = (e) => {
      if (["ArrowUp", "Space", "KeyP"].includes(e.code)) e.preventDefault();
      keysRef.current[e.code] = true;
      if (e.code === "KeyP" && screenRef.current === "playing") {
        setIsPaused(prev => {
          const next = !prev;
          isPausedRef.current = next;
          if (!next) lastTimeRef.current = 0;
          return next;
        });
      }
      // Hidden level skip: press 1-5 during gameplay to jump to that level
      const levelKeys = { Digit1: 0, Digit2: 1, Digit3: 2 };
      if (levelKeys[e.code] !== undefined && screenRef.current === "playing") {
        const targetLevel = levelKeys[e.code];
        if (targetLevel < TOTAL_LEVELS) {
          const gs = gsRef.current;
          const cs = gs ? gs.score : 0;
          const cl = gs ? gs.lives : MAX_LIVES;
          setCurrentLevel(targetLevel);
          initGameState(targetLevel, cs, cl);
          setShowLevelIntro(true);
          setIntroData(LEVEL_DATA[targetLevel]);
          isPausedRef.current = false;
          setIsPaused(false);
          setTimeout(() => setShowLevelIntro(false), 3000);
        }
      }
    };
    const handleUp = (e) => { keysRef.current[e.code] = false; };
    window.addEventListener("keydown", handleDown);
    window.addEventListener("keyup", handleUp);
    return () => {
      window.removeEventListener("keydown", handleDown);
      window.removeEventListener("keyup", handleUp);
    };
  }, []);

  // ====== MAIN GAME LOOP ======
  useEffect(() => {
    if (screen !== "playing" || showLevelIntro) {
      if (animRef.current) cancelAnimationFrame(animRef.current);
      return;
    }
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    const loop = (timestamp) => {
      const gs = gsRef.current;
      if (!gs || !gs.running) return;

      if (isPausedRef.current) {
        ctx.fillStyle = "rgba(0,0,0,0.6)";
        ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
        ctx.font = `20px ${PIXEL_FONT}`;
        ctx.fillStyle = "#ffdd59";
        ctx.textAlign = "center";
        ctx.fillText("PAUSED", GAME_WIDTH / 2, GAME_HEIGHT / 2 - 10);
        ctx.font = `9px ${PIXEL_FONT}`;
        ctx.fillStyle = "#a0a0c0";
        ctx.fillText("PRESS P OR CLICK PAUSE TO RESUME", GAME_WIDTH / 2, GAME_HEIGHT / 2 + 20);
        animRef.current = requestAnimationFrame(loop);
        return;
      }

      if (lastTimeRef.current === 0) lastTimeRef.current = timestamp;
      const dt = Math.min(timestamp - lastTimeRef.current, 33);
      lastTimeRef.current = timestamp;
      gs.frameCount++;

      const ld = LEVEL_DATA[gs.level];
      const isCovid = ld.covid;

      // Timer
      gs.timeLeft -= dt / 1000;
      setTimeLeft(Math.max(0, Math.ceil(gs.timeLeft)));
      if (gs.timeLeft <= 0) {
        const nextLvl = gs.level + 1;
        if (nextLvl >= TOTAL_LEVELS) {
          gs.running = false;
          endGame(gs.score, TOTAL_LEVELS);
          setScreen("victory");
          return;
        }
        const cs = gs.score, cl = gs.lives;
        setCurrentLevel(nextLvl);
        initGameState(nextLvl, cs, cl);
        setShowLevelIntro(true);
        setIntroData(LEVEL_DATA[nextLvl]);
        setTimeout(() => setShowLevelIntro(false), 3000);
        return;
      }

      // COVID banner fade
      if (gs.covidBannerTimer > 0) {
        gs.covidBannerTimer--;
        if (gs.covidBannerTimer < 60) gs.covidBannerAlpha = gs.covidBannerTimer / 60;
      }

      // ===== TAKEOUT CAR LOGIC (COVID level only) =====
      const takeoutWindowStart = TAKEOUT_START;
      const takeoutWindowEnd = TAKEOUT_START - TAKEOUT_DURATION;
      const inTakeoutWindow = isCovid && gs.timeLeft <= takeoutWindowStart && gs.timeLeft > takeoutWindowEnd;

      if (isCovid && gs.timeLeft <= takeoutWindowStart && !gs.takeoutTriggered) {
        gs.takeoutTriggered = true;
        gs.takeoutCarState = "entering";
        gs.takeoutActive = false;
      }

      // Car animation
      const carTargetX = GAME_WIDTH - 130;
      if (gs.takeoutCarState === "entering") {
        gs.takeoutCarX -= 3;
        if (gs.takeoutCarX <= carTargetX) {
          gs.takeoutCarX = carTargetX;
          gs.takeoutCarState = "parked";
          gs.takeoutActive = true;
          gs.takeoutTimer = TAKEOUT_DURATION;
        }
      } else if (gs.takeoutCarState === "parked") {
        if (!inTakeoutWindow) {
          gs.takeoutCarState = "leaving";
          gs.takeoutActive = false;
        }
      } else if (gs.takeoutCarState === "leaving") {
        gs.takeoutCarX += 5;
        if (gs.takeoutCarX > GAME_WIDTH + 130) {
          gs.takeoutCarState = "hidden";
        }
      }

      // Takeout cooldown
      if (gs.takeoutCooldown > 0) gs.takeoutCooldown--;

      // ===== BEEF PRICE HIKE (Level 5) =====
      const isLevel5 = gs.level === 2;
      const beefWindowEnd = BEEF_HIKE_START - BEEF_HIKE_DURATION;
      const inBeefWindow = isLevel5 && gs.timeLeft <= BEEF_HIKE_START && gs.timeLeft > beefWindowEnd;

      if (isLevel5 && gs.timeLeft <= BEEF_HIKE_START && !gs.beefHikeTriggered) {
        gs.beefHikeTriggered = true;
        gs.beefHikeActive = true;
        gs.beefBannerAlpha = 1.0;
        gs.beefBannerTimer = 120;
      }
      if (gs.beefHikeActive && !inBeefWindow) {
        gs.beefHikeActive = false;
      }
      if (gs.beefBannerTimer > 0) {
        gs.beefBannerTimer--;
        if (gs.beefBannerTimer < 60) gs.beefBannerAlpha = gs.beefBannerTimer / 60;
      }

      // ===== INPUT =====
      if (gs.takeoutActive) {
        // During takeout phase: spacebar throws bags, jump still works
        if (keysRef.current["ArrowUp"] && !gs.player.isJumping) {
          gs.player.vy = JUMP_FORCE;
          gs.player.isJumping = true;
        }
        if (keysRef.current["Space"] && gs.takeoutCooldown <= 0) {
          // Throw a takeout bag
          gs.takeoutBags.push({
            x: gs.player.x + 30,
            y: GROUND_Y - 36,
            vx: 10,
            vy: 0,
            active: true,
          });
          gs.takeoutCooldown = 18;
          keysRef.current["Space"] = false;
        }
      } else if (gs.beefHikeActive) {
        // During beef hike: spacebar throws burgers at cows
        if (keysRef.current["ArrowUp"] && !gs.player.isJumping) {
          gs.player.vy = JUMP_FORCE;
          gs.player.isJumping = true;
        }
        if (keysRef.current["Space"] && gs.beefCooldown <= 0) {
          gs.burgerProjectiles.push({
            x: gs.player.x + 30,
            y: GROUND_Y - 30,
            vx: 9,
            vy: 0,
            active: true,
          });
          gs.beefCooldown = 14;
          keysRef.current["Space"] = false;
        }
      } else {
        if (keysRef.current["ArrowUp"] && !gs.player.isJumping) {
          gs.player.vy = JUMP_FORCE;
          gs.player.isJumping = true;
        }
        if (keysRef.current["Space"] && gs.swordCooldown <= 0) {
          gs.swordActive = true;
          gs.swordTimer = 15;
          gs.swordCooldown = 20;
          gs.slashFrame = 0;
          keysRef.current["Space"] = false;
        }
      }

      // Physics
      gs.player.vy += GRAVITY;
      gs.player.y += gs.player.vy;
      if (gs.player.y >= GROUND_Y - PLAYER_HEIGHT) {
        gs.player.y = GROUND_Y - PLAYER_HEIGHT;
        gs.player.vy = 0;
        gs.player.isJumping = false;
      }
      gs.scroll += gs.speed;
      gs.player.frame += 0.15;

      // Timers
      if (gs.swordTimer > 0) gs.swordTimer--; else gs.swordActive = false;
      if (gs.swordCooldown > 0) gs.swordCooldown--;
      if (gs.slashFrame >= 0) gs.slashFrame++;
      if (gs.slashFrame > 10) gs.slashFrame = -1;
      if (gs.invincible > 0) gs.invincible--;
      if (gs.hitFlash > 0) gs.hitFlash--;
      if (gs.shakeX > 0.5) gs.shakeX *= 0.8; else gs.shakeX = 0;
      if (gs.shakeY > 0.5) gs.shakeY *= 0.8; else gs.shakeY = 0;
      if (gs.comboTimer > 0) { gs.comboTimer--; if (gs.comboTimer <= 0) gs.combo = 0; }
      setDisplayCombo(gs.combo);

      // ===== TAKEOUT BAG PHYSICS =====
      gs.takeoutBags.forEach(bag => {
        if (!bag.active) return;
        bag.x += bag.vx;
        bag.y += bag.vy;
        // Check if bag hits the car trunk area
        if (gs.takeoutCarState === "parked" &&
            bag.x >= gs.takeoutCarX - 8 && bag.x <= gs.takeoutCarX + 10 &&
            bag.y >= GROUND_Y - 50 && bag.y <= GROUND_Y - 10) {
          bag.active = false;
          gs.score += TAKEOUT_POINTS;
          setDisplayScore(gs.score);
          gs.scorePopups.push({ x: bag.x, y: bag.y - 10, text: `+${TAKEOUT_POINTS}`, color: "#5f5", life: 1 });
          // Bag disappear particles
          for (let j = 0; j < 4; j++) {
            gs.particles.push({
              x: bag.x, y: bag.y,
              vx: (Math.random() - 0.5) * 3, vy: -Math.random() * 3,
              life: 0.8, color: "#c49a6c", size: 2 + Math.random() * 2,
            });
          }
        }
        // Remove if off-screen or hit ground
        if (bag.x > GAME_WIDTH + 20 || bag.y > GROUND_Y) bag.active = false;
      });
      gs.takeoutBags = gs.takeoutBags.filter(b => b.active);

      // ===== BEEF COOLDOWN & BURGER PROJECTILES =====
      if (gs.beefCooldown > 0) gs.beefCooldown--;
      gs.burgerProjectiles.forEach(b => {
        if (!b.active) return;
        b.x += b.vx;
        // Check collision with cow obstacles
        for (let i = 0; i < gs.obstacles.length; i++) {
          const o = gs.obstacles[i];
          if (o.hit || o.food !== "cow") continue;
          if (b.x + 12 >= o.x && b.x <= o.x + o.w &&
              b.y + 10 >= o.y && b.y <= o.y + o.h) {
            b.active = false;
            o.hit = true;
            gs.score += 1;
            setDisplayScore(gs.score);
            gs.scorePopups.push({ x: o.x + o.w / 2, y: o.y - 20, text: `+1`, color: "#ff0", life: 1 });
            for (let j = 0; j < 8; j++) {
              gs.particles.push({
                x: o.x + o.w / 2, y: o.y + o.h / 2,
                vx: (Math.random() - 0.5) * 8, vy: (Math.random() - 0.5) * 6 - 2,
                life: 1, color: ["#1a1a1a", "#4a3a2a", "#d4881c"][j % 3], size: 3 + Math.random() * 4,
              });
            }
            break;
          }
        }
        if (b.x > GAME_WIDTH + 20) b.active = false;
      });
      gs.burgerProjectiles = gs.burgerProjectiles.filter(b => b.active);

      // ===== SPAWN OBSTACLES (not during takeout) =====
      if (!gs.takeoutActive) {
        spawnAccumRef.current += dt;
        // During beef hike: spawn cows back-to-back (no gap)
        const currentSpawnTarget = gs.beefHikeActive ? 10 : nextSpawnRef.current; // very fast spawn to fill screen
        if (spawnAccumRef.current >= currentSpawnTarget) {
          spawnAccumRef.current = 0;
          if (!gs.beefHikeActive) nextSpawnRef.current = randomSpawnDelay(gs.level);

          let food, w, h;
          if (gs.beefHikeActive) {
            // Only spawn if there's no cow right at the edge (prevents stacking)
            const lastCow = gs.obstacles.filter(o => o.food === "cow" && !o.hit).pop();
            if (!lastCow || lastCow.x < GAME_WIDTH - 48) {
              food = "cow";
              w = 50; h = 36;
            } else {
              food = null; // skip this spawn
            }
          } else {
            const types = isCovid ? [...FOOD_TYPES, ...COVID_TYPES] : FOOD_TYPES;
            food = types[Math.floor(Math.random() * types.length)];
            if (food === "pizza") { w = 34; h = 34; }
            else if (food === "burger") { w = 36; h = 30; }
            else if (food === "egg") { w = 28; h = 32; }
            else if (food === "mask") { w = 38; h = 24; }
            else if (food === "distancing") { w = 40; h = 40; }
            else { w = 26; h = 38; }
          }
          if (food) {
            gs.obstacles.push({
              x: GAME_WIDTH + 20, y: GROUND_Y - h,
              w, h, food, hit: false, jumped: false, stomped: false,
            });
          }
        }
      }

      // Move obstacles (cows move slower during beef hike)
      gs.obstacles.forEach(o => {
        if (o.food === "cow" && gs.beefHikeActive) {
          o.x -= gs.speed * 0.4; // slow march
        } else {
          o.x -= gs.speed;
        }
      });

      const px = gs.player.x;
      const py = gs.player.y;

      // ===== COLLISION =====
      const swordBox = gs.swordActive ? { x: px + 28, y: py + 10, w: 20, h: 30 } : null;
      const feetBox = { x: px + 10, y: py + PLAYER_HEIGHT - 8, w: 20, h: 8 };
      const bodyBox = { x: px + 8, y: py + 4, w: 24, h: 48 };

      for (let i = 0; i < gs.obstacles.length; i++) {
        const o = gs.obstacles[i];
        if (o.hit || o.jumped || o.stomped) continue;
        const ox = o.x, oy = o.y, ow = o.w, oh = o.h;

        if (swordBox && swordBox.x < ox + ow && swordBox.x + swordBox.w > ox &&
            swordBox.y < oy + oh && swordBox.y + swordBox.h > oy) {
          o.hit = true;
          gs.combo++;
          gs.comboTimer = 90;
          gs.score += SMASH_POINTS;
          setDisplayScore(gs.score);
          gs.scorePopups.push({ x: ox + ow / 2, y: oy - 20, text: `+${SMASH_POINTS}`, color: "#ff0", life: 1 });
          const colors = o.food === "pizza" ? ["#f0c040", "#cc3333", "#c8900a"]
            : o.food === "burger" ? ["#d4881c", "#6b3a1f", "#5cb85c"]
            : o.food === "egg" ? ["#fef9e7", "#f0d060", "#c4a96a"]
            : o.food === "mask" ? ["#7ec8e3", "#5ba3c9", "#fff"]
            : o.food === "distancing" ? ["#cc0000", "#fff", "#333"]
            : o.food === "cow" ? ["#1a1a1a", "#4a3a2a", "#c8a870"]
            : ["#e74c3c", "#c0392b", "#fff"];
          for (let j = 0; j < 8; j++) {
            gs.particles.push({
              x: ox + ow / 2, y: oy + oh / 2,
              vx: (Math.random() - 0.5) * 8, vy: (Math.random() - 0.5) * 8 - 2,
              life: 1, color: colors[j % colors.length], size: 3 + Math.random() * 4,
            });
          }
          continue;
        }

        if (gs.player.vy > 0 && gs.player.isJumping &&
            feetBox.x < ox + ow && feetBox.x + feetBox.w > ox &&
            feetBox.y >= oy - 4 && feetBox.y <= oy + 8) {
          o.stomped = true;
          o.hit = true;
          gs.player.vy = JUMP_FORCE * 0.6;
          gs.score += STOMP_POINTS;
          setDisplayScore(gs.score);
          gs.scorePopups.push({ x: ox + ow / 2, y: oy - 20, text: `+${STOMP_POINTS} STOMP!`, color: "#5bf", life: 1 });
          for (let j = 0; j < 5; j++) {
            gs.particles.push({
              x: ox + ow / 2, y: oy + oh,
              vx: (Math.random() - 0.5) * 6, vy: -Math.random() * 2,
              life: 1, color: "#ffdd59", size: 2 + Math.random() * 3,
            });
          }
          continue;
        }

        if (bodyBox.x < ox + ow && bodyBox.x + bodyBox.w > ox &&
            bodyBox.y < oy + oh && bodyBox.y + bodyBox.h > oy) {
          if (gs.invincible <= 0) {
            o.hit = true;
            gs.lives--;
            gs.invincible = 90;
            gs.hitFlash = 20;
            gs.combo = 0;
            gs.shakeX = 8;
            gs.shakeY = 5;
            setDisplayLives(gs.lives);
            if (gs.lives <= 0) {
              gs.running = false;
              endGame(gs.score, gs.level + 1);
              setScreen("gameover");
              return;
            }
            for (let j = 0; j < 5; j++) {
              gs.particles.push({
                x: px + 20, y: py + 28,
                vx: (Math.random() - 0.5) * 4, vy: -Math.random() * 4,
                life: 1, color: "#ff0000", size: 4,
              });
            }
          }
        }
      }

      // Jump-over scoring
      gs.obstacles.forEach(o => {
        if (o.hit || o.jumped || o.stomped) return;
        if (o.x + o.w < px) {
          o.jumped = true;
          gs.score += JUMP_POINTS;
          setDisplayScore(gs.score);
          gs.scorePopups.push({ x: o.x + o.w / 2, y: o.y - 20, text: `+${JUMP_POINTS}`, color: "#5bf", life: 1 });
        }
      });

      gs.obstacles = gs.obstacles.filter(o => !o.hit && o.x > -80);

      // Update particles & popups
      gs.particles.forEach(p => { p.x += p.vx; p.y += p.vy; p.vy += 0.1; p.life -= 0.03; });
      gs.particles = gs.particles.filter(p => p.life > 0);
      gs.scorePopups.forEach(p => { p.y -= 1; p.life -= 0.02; });
      gs.scorePopups = gs.scorePopups.filter(p => p.life > 0);

      // ===== DRAW =====
      const shx = gs.shakeX > 0 ? (Math.random() - 0.5) * gs.shakeX : 0;
      const shy = gs.shakeY > 0 ? (Math.random() - 0.5) * gs.shakeY : 0;

      ctx.save();
      ctx.translate(shx, shy);

      ctx.fillStyle = ld.bg;
      ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

      // COVID red fog overlay
      if (isCovid) {
        ctx.fillStyle = "rgba(100,0,0,0.1)";
        ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
      }

      drawClouds(ctx, gs.scroll);
      drawBuildings(ctx, gs.scroll, ld.locations);
      drawGround(ctx, gs.scroll, isCovid);

      // Draw car if visible
      if (gs.takeoutCarState !== "hidden") {
        drawCar(ctx, gs.takeoutCarX, gs.takeoutCarState === "parked");
      }

      // Obstacles
      gs.obstacles.forEach(o => { if (!o.hit) drawFoodObstacle(ctx, o); });

      // Takeout bags in flight
      gs.takeoutBags.forEach(bag => { if (bag.active) drawTakeoutBag(ctx, bag); });

      // Burger projectiles in flight
      gs.burgerProjectiles.forEach(b => {
        if (!b.active) return;
        // Mini burger projectile
        ctx.fillStyle = "#d4881c";
        ctx.fillRect(b.x, b.y, 12, 4);
        ctx.fillRect(b.x + 1, b.y - 2, 10, 3);
        ctx.fillStyle = "#6b3a1f";
        ctx.fillRect(b.x + 1, b.y + 3, 10, 3);
        ctx.fillStyle = "#5cb85c";
        ctx.fillRect(b.x, b.y + 3, 12, 2);
        ctx.fillStyle = "#d4881c";
        ctx.fillRect(b.x + 1, b.y + 6, 10, 3);
      });

      // Player
      if (gs.invincible <= 0 || gs.frameCount % 4 < 2) {
        if (gs.hitFlash > 0) ctx.globalAlpha = 0.5 + Math.sin(gs.frameCount * 0.5) * 0.3;
        drawPixelChar(ctx, gs.player.x, gs.player.y, Math.floor(gs.player.frame), gs.player.isJumping, gs.swordActive && !gs.takeoutActive, genderRef.current);
        ctx.globalAlpha = 1;
      }

      if (gs.slashFrame >= 0 && gs.slashFrame < 10 && !gs.takeoutActive) {
        drawSwordSlash(ctx, gs.player.x, gs.player.y, gs.slashFrame);
      }

      gs.particles.forEach(p => drawParticle(ctx, p));
      gs.scorePopups.forEach(p => drawScorePopup(ctx, p));

      // COVID banner
      if (isCovid && gs.covidBannerAlpha > 0) {
        drawCovidBanner(ctx, gs.scroll, gs.covidBannerAlpha);
      }

      // Beef Price Hike banner
      if (gs.beefBannerAlpha > 0) {
        drawBeefBanner(ctx, gs.scroll, gs.beefBannerAlpha);
      }

      ctx.restore();

      // ===== HUD =====
      ctx.fillStyle = "rgba(0,0,0,0.7)";
      ctx.fillRect(0, 0, GAME_WIDTH, 36);

      ctx.font = `10px ${PIXEL_FONT}`;
      ctx.fillStyle = "#fff";
      ctx.textAlign = "left";
      ctx.fillText(`SCORE: ${gs.score}`, 10, 22);

      ctx.textAlign = "center";
      const tl = Math.ceil(gs.timeLeft);
      ctx.fillStyle = tl <= 10 ? "#ff4757" : "#fff";
      ctx.fillText(`LAUNCH IN: ${tl}s`, GAME_WIDTH / 2, 22);

      drawHealthBar(ctx, gs.lives, MAX_LIVES);

      if (gs.combo > 1) {
        ctx.textAlign = "center";
        ctx.fillStyle = "#ffdd59";
        ctx.font = `bold 14px ${PIXEL_FONT}`;
        ctx.fillText(`${gs.combo}x COMBO!`, GAME_WIDTH / 2, 60);
      }

      // Takeout mode HUD
      if (gs.takeoutActive) {
        const takeoutSecsLeft = Math.max(0, Math.ceil(gs.timeLeft - takeoutWindowEnd));
        ctx.textAlign = "center";
        ctx.font = `10px ${PIXEL_FONT}`;
        if (gs.frameCount % 40 < 25) {
          ctx.fillStyle = "#5f5";
          ctx.fillText("SPACEBAR FOR TAKEOUT ORDERS!", GAME_WIDTH / 2, GAME_HEIGHT - 40);
        }
        ctx.fillStyle = "#5f5";
        ctx.font = `8px ${PIXEL_FONT}`;
        ctx.fillText(`TAKEOUT: ${takeoutSecsLeft}s`, GAME_WIDTH / 2, GAME_HEIGHT - 24);
      } else if (gs.beefHikeActive) {
        // Beef hike countdown
        const beefSecsLeft = Math.max(0, Math.ceil(gs.timeLeft - beefWindowEnd));
        ctx.textAlign = "center";
        ctx.font = `10px ${PIXEL_FONT}`;
        if (gs.frameCount % 30 < 20) {
          ctx.fillStyle = "#ff6b35";
          ctx.fillText("SPACEBAR TO THROW BURGERS!", GAME_WIDTH / 2, GAME_HEIGHT - 40);
        }
        ctx.fillStyle = "#ffcc00";
        ctx.font = `8px ${PIXEL_FONT}`;
        ctx.fillText(`${beefSecsLeft}s`, GAME_WIDTH / 2, GAME_HEIGHT - 24);
        // Still show sword bar
        ctx.font = `7px ${PIXEL_FONT}`;
        ctx.textAlign = "left";
        if (gs.swordCooldown > 0) {
          ctx.fillStyle = "rgba(255,255,255,0.3)";
          ctx.fillRect(10, GAME_HEIGHT - 20, 60, 8);
          ctx.fillStyle = "#ffdd59";
          ctx.fillRect(10, GAME_HEIGHT - 20, 60 * (1 - gs.swordCooldown / 20), 8);
        } else {
          ctx.fillStyle = "#ffdd59";
          ctx.fillRect(10, GAME_HEIGHT - 20, 60, 8);
          ctx.fillStyle = "#000";
          ctx.fillText("SWORD", 14, GAME_HEIGHT - 13);
        }
      } else {
        // Sword cooldown bar (only when not in takeout mode)
        ctx.font = `7px ${PIXEL_FONT}`;
        ctx.textAlign = "left";
        if (gs.swordCooldown > 0) {
          ctx.fillStyle = "rgba(255,255,255,0.3)";
          ctx.fillRect(10, GAME_HEIGHT - 20, 60, 8);
          ctx.fillStyle = "#ffdd59";
          ctx.fillRect(10, GAME_HEIGHT - 20, 60 * (1 - gs.swordCooldown / 20), 8);
        } else {
          ctx.fillStyle = "#ffdd59";
          ctx.fillRect(10, GAME_HEIGHT - 20, 60, 8);
          ctx.fillStyle = "#000";
          ctx.fillText("SWORD", 14, GAME_HEIGHT - 13);
        }
      }

      animRef.current = requestAnimationFrame(loop);
    };

    animRef.current = requestAnimationFrame(loop);
    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
  }, [screen, showLevelIntro, initGameState, endGame, randomSpawnDelay]);

  // ====== SCREENS ======

  const fontLink = null;

  const baseStyle = {
    fontFamily: PIXEL_FONT, background: "#0a0a23", minHeight: "100vh",
    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
    color: "#fff", imageRendering: "pixelated", overflow: "hidden",
  };

  const heroBtnStyle = (selected) => ({
    background: selected ? "rgba(74,105,189,0.3)" : "rgba(26,26,64,0.5)",
    border: `3px solid ${selected ? "#ffdd59" : "#4a69bd"}`,
    cursor: "pointer", transition: "all 0.15s",
    padding: "8px 12px", display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
    boxShadow: selected ? "0 0 12px rgba(255,221,89,0.3)" : "none",
  });

  const CharPreview = ({ charGender, selected }) => {
    const miniRef = useRef(null);
    useEffect(() => {
      const c = miniRef.current;
      if (!c) return;
      const cx = c.getContext("2d");
      cx.clearRect(0, 0, 60, 70);
      if (charGender === "female") drawFemaleChar(cx, 10, 6, 0, false, false);
      else drawMaleChar(cx, 10, 6, 0, false, false);
    }, [charGender]);
    return <canvas ref={miniRef} width={60} height={70} style={{ imageRendering: "pixelated" }} />;
  };

  if (screen === "title") {
    return (
      <div style={baseStyle}>
        {fontLink}
        <div style={{ textAlign: "center", maxWidth: 700 }}>
          <div style={{ fontSize: 10, color: "#a29bfe", marginBottom: 8, letterSpacing: 4 }}>PRESENTS</div>
          <h1 style={{ fontFamily: PIXEL_FONT, fontSize: 28, color: "#ffdd59", textShadow: "3px 3px 0 #e74c3c, 6px 6px 0 rgba(0,0,0,0.3)", lineHeight: 1.4, marginBottom: 6 }}>MENU CAMPAIGN</h1>
          <h1 style={{ fontFamily: PIXEL_FONT, fontSize: 36, color: "#ff6b6b", textShadow: "3px 3px 0 #c0392b, 6px 6px 0 rgba(0,0,0,0.3)", lineHeight: 1.4, marginBottom: 20 }}>RUSH!</h1>
          <div style={{ fontSize: 9, color: "#a0a0c0", lineHeight: 2.2, marginBottom: 24, maxWidth: 520, margin: "0 auto 24px" }}>
            <p>YOU ARE A RESTAURANT MARKETER.</p>
            <p>LAUNCH DAY IS COMING. MENUS MUST SHIP.</p>
            <p>PRICE INCREASES ARE FLYING AT YOU!</p>
            <p>SMASH, STOMP, OR JUMP OVER THEM!</p>
            <p style={{ color: "#ffdd59", marginTop: 8 }}>↑ JUMP (+2) &nbsp; SPACE SWORD (+5) &nbsp; STOMP (+2)</p>
          </div>
          <div style={{ marginBottom: 16 }}>
            <input type="text" value={playerName} onChange={e => setPlayerName(e.target.value.slice(0, 12))}
              onKeyDown={e => { if (e.key === "Enter") startGame(); }} placeholder="ENTER YOUR NAME" maxLength={12}
              style={{ fontFamily: PIXEL_FONT, fontSize: 12, padding: "10px 16px", background: "#1a1a40", border: "3px solid #4a69bd", color: "#fff", textAlign: "center", outline: "none", width: 260 }} />
          </div>
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 11, color: "#ffdd59", marginBottom: 10, textShadow: "1px 1px 0 #e74c3c" }}>CHOOSE YOUR HERO</div>
            <div style={{ display: "flex", gap: 16, justifyContent: "center" }}>
              <div onClick={() => setGender("male")} style={heroBtnStyle(gender === "male")}>
                <CharPreview charGender="male" selected={gender === "male"} />
              </div>
              <div onClick={() => setGender("female")} style={heroBtnStyle(gender === "female")}>
                <CharPreview charGender="female" selected={gender === "female"} />
              </div>
            </div>
          </div>
          <button onClick={startGame} disabled={!playerName.trim()}
            style={{ fontFamily: PIXEL_FONT, fontSize: 14, padding: "12px 32px", background: playerName.trim() ? "#e74c3c" : "#555", color: "#fff", border: "none", cursor: playerName.trim() ? "pointer" : "default", boxShadow: playerName.trim() ? "0 4px 0 #c0392b" : "none" }}>
            START GAME
          </button>
          <div style={{ marginTop: 30, fontSize: 9 }}>
            <div style={{ color: "#ffdd59", marginBottom: 10, fontSize: 11 }}>TOP SCORES</div>
            {leaderboard.length > 0 ? leaderboard.slice(0, 7).map((entry, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", width: 340, margin: "0 auto", padding: "5px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", color: i === 0 ? "#ffdd59" : i === 1 ? "#c0c0c0" : i === 2 ? "#cd7f32" : "#a0a0c0" }}>
                <span>{i + 1}. {entry.name}</span>
                <span>{entry.score} PTS</span>
              </div>
            )) : (
              <div style={{ color: "#555", padding: "10px 0" }}>NO SCORES YET - BE THE FIRST!</div>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (screen === "playing") {
    const ld = LEVEL_DATA[currentLevel];
    return (
      <div style={baseStyle}>
        {fontLink}
        {showLevelIntro ? (
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 10, color: ld.covid ? "#ff4444" : "#a29bfe", marginBottom: 12 }}>YEAR {ld.year}</div>
            <div style={{ fontSize: 22, color: ld.covid ? "#ff0000" : "#ffdd59", marginBottom: 8, textShadow: "2px 2px 0 " + (ld.covid ? "#660000" : "#e74c3c") }}>
              LEVEL {currentLevel + 1}
            </div>
            <div style={{ fontSize: 14, color: ld.covid ? "#ff4444" : "#ff6b6b", marginBottom: 16 }}>{ld.name}</div>
            <div style={{ fontSize: 10, color: "#a0a0c0", lineHeight: 2 }}>
              <p>{ld.locations} LOCATION{ld.locations > 1 ? "S" : ""} TO UPDATE</p>
              {ld.covid ? (
                <>
                  <p style={{ color: "#ff6666" }}>MASKS AND DISTANCING INCOMING!</p>
                  <p style={{ color: "#5f5" }}>TAKEOUT ORDERS AT THE HALFWAY MARK!</p>
                </>
              ) : (
                <p>MENUS LAUNCH IN 35 SECONDS!</p>
              )}
            </div>
          </div>
        ) : (
          <div style={{ position: "relative" }}>
            <div style={{ fontSize: 9, textAlign: "center", color: ld.covid ? "#ff6666" : "#a0a0c0", marginBottom: 4 }}>
              LEVEL {currentLevel + 1} - {ld.name} ({ld.year}) - {ld.locations} LOCATIONS
            </div>
            <canvas ref={canvasRef} width={GAME_WIDTH} height={GAME_HEIGHT}
              style={{ border: `3px solid ${ld.covid ? "#660000" : "#4a69bd"}`, display: "block", imageRendering: "pixelated", maxWidth: "100%", background: "#000" }} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 8, color: "#a0a0c0", marginTop: 6, padding: "0 4px", maxWidth: GAME_WIDTH }}>
              <span>↑ JUMP (+2)</span>
              <span>SPACE SWORD (+5)</span>
              <span>STOMP (+2)</span>
              <span>P PAUSE</span>
              <button onClick={togglePause}
                style={{
                  fontFamily: PIXEL_FONT, fontSize: 9, padding: "6px 14px",
                  background: isPaused ? "#27ae60" : "#e74c3c", color: "#fff",
                  border: "2px solid " + (isPaused ? "#1e8449" : "#c0392b"),
                  cursor: "pointer", boxShadow: "0 2px 0 " + (isPaused ? "#1e8449" : "#c0392b"),
                }}>
                {isPaused ? "RESUME" : "PAUSE"}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (screen === "gameover") {
    return (
      <div style={baseStyle}>
        {fontLink}
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 28, color: "#ff4757", marginBottom: 20, textShadow: "3px 3px 0 #c0392b" }}>GAME OVER</div>
          <div style={{ fontSize: 10, color: "#a0a0c0", marginBottom: 8 }}>THE MENUS DIDN'T MAKE IT IN TIME...</div>
          <div style={{ fontSize: 10, color: "#a0a0c0", marginBottom: 20 }}>REACHED LEVEL {currentLevel + 1} OF {TOTAL_LEVELS}</div>
          <div style={{ fontSize: 16, color: "#ffdd59", marginBottom: 30 }}>SCORE: {gameOverScore}</div>
          <button onClick={() => setScreen("title")}
            style={{ fontFamily: PIXEL_FONT, fontSize: 12, padding: "10px 28px", background: "#e74c3c", color: "#fff", border: "none", cursor: "pointer", boxShadow: "0 4px 0 #c0392b" }}>
            TRY AGAIN
          </button>
        </div>
      </div>
    );
  }

  if (screen === "victory") {
    return (
      <div style={baseStyle}>
        {fontLink}
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 24, color: "#ffdd59", marginBottom: 16, textShadow: "3px 3px 0 #e74c3c" }}>YOU DID IT!</div>
          <div style={{ fontSize: 10, color: "#a0a0c0", marginBottom: 8, lineHeight: 2 }}>
            <p>ALL 2,500 LOCATIONS UPDATED!</p>
            <p>3 YEARS OF MENU CHAOS SURVIVED!</p>
            <p>THE NEW MENU IS LIVE!</p>
          </div>
          <div style={{ fontSize: 18, color: "#ffdd59", marginBottom: 30 }}>FINAL SCORE: {gameOverScore}</div>
          <button onClick={() => setScreen("title")}
            style={{ fontFamily: PIXEL_FONT, fontSize: 12, padding: "10px 28px", background: "#27ae60", color: "#fff", border: "none", cursor: "pointer", boxShadow: "0 4px 0 #1e8449" }}>
            PLAY AGAIN
          </button>
        </div>
      </div>
    );
  }

  return null;
}
