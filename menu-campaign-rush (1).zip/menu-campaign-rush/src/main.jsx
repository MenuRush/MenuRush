import React from 'react'
import ReactDOM from 'react-dom/client'
import MenuCampaignRush from './MenuCampaignRush.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MenuCampaignRush />
  </React.StrictMode>,
)
